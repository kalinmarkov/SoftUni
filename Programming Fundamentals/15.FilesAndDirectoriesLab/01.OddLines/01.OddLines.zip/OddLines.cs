﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace _01.OddLines
{
    class OddLines
    {
        static void Main()
        {
            string[] textLines = File.ReadAllLines("input.txt");

            List<string> onlyOddLines = new List<string>();

            for (int i = 1; i < textLines.Length; i += 2)
            {
                onlyOddLines.Add(textLines[i]);
            }

            File.WriteAllLines("result.txt", onlyOddLines);
        }
    }
}
